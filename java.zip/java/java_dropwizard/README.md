# Dropwizard Prometheus Java Example

This is a simple example of how to expose existing Dropwizard
metrics with the Prometheus Java client.

