https://www.robustperception.io/instrumenting-java-with-prometheus
cd java_examples/java_simple/
mvn package
java -jar target/java_simple-1.0-SNAPSHOT-jar-with-dependencies.jar
If you visit http://localhost:1234/ you'll see Hello World, and on http://localhost:1234/metrics you can see the metrics.

Notice how hello_worlds_total increments every time you get a Hello World. This is an example of a Counter, one of the basic Prometheus metric types. So how does it work?