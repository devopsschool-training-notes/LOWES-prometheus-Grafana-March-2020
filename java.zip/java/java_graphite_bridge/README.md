# Prometheus Java Graphite Bridge Example

This is a simple example of how to export to Graphite with the Java client.

For more information see https://www.robustperception.io/exporting-to-graphite-with-the-prometheus-java-client
