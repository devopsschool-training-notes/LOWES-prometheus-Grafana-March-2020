# Simple Prometheus Java Example

This is a simple example of how to export a Counter with Prometheus.

For more information see http://www.robustperception.io/instrumenting-java-with-prometheus/
